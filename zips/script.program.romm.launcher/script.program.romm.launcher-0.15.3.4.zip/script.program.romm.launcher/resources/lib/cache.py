# -*- coding: utf-8 -*-
import os, time, json
from .utils import JSON_CACHE, IMG_CACHE, hash_str, log, get_setting_int
def _cache_path_for(url_or_key, subdir):
    h = hash_str(url_or_key); return os.path.join(subdir, h)
def get_json(url, fetcher, ttl_days=None):
    ttl_days = ttl_days if ttl_days is not None else get_setting_int('cache_days', 3)
    cache_file = _cache_path_for(url, JSON_CACHE)
    if os.path.exists(cache_file):
        try:
            with open(cache_file, 'r', encoding='utf-8') as f: blob = json.load(f)
            if (time.time() - blob.get('_ts', 0)) < ttl_days * 86400: return blob.get('data', None)
        except Exception: pass
    data = fetcher()
    try:
        with open(cache_file, 'w', encoding='utf-8') as f: json.dump({'_ts': time.time(), 'data': data}, f, ensure_ascii=False)
    except Exception as e: log(f"Failed to write JSON cache: {e}")
    return data
def get_image(url, opener, ttl_days=None):
    ttl_days = ttl_days if ttl_days is not None else get_setting_int('cache_days', 3)
    cache_file = _cache_path_for(url, IMG_CACHE)
    if os.path.exists(cache_file) and (time.time() - os.path.getmtime(cache_file)) < ttl_days * 86400: return cache_file
    try:
        data = opener(url); open(cache_file, 'wb').write(data); return cache_file
    except Exception as e:
        log(f"Image cache fetch failed: {e}"); return ''
