# -*- coding: utf-8 -*-
import os, sys, json, urllib.parse, re, time, threading
from urllib.error import HTTPError, URLError
import xbmc, xbmcaddon, xbmcgui, xbmcplugin, xbmcvfs, time
import xbmcaddon
import shlex


try:
    from resources.lib.launcher import launch_game_async
except Exception:
    from resources.lib.launcher import launch_game as _blocking_launch
    import threading as _t
    def launch_game_async(pid, path):
        th = _t.Thread(target=_blocking_launch, args=(pid, path), daemon=True)
        th.start()
        return True

from resources.lib.utils import (ADDON, ADDON_PATH, MEDIA_PATH, ensure_dirs, get_setting, get_setting_bool, get_setting_int, is_windows, log, notify, path_join, find_media_image)
from resources.lib.cache import get_image
from resources.lib.romm_client import RomMClient
from resources.lib import installed
from collections import defaultdict

HANDLE = int(sys.argv[1]); BASE_URL = sys.argv[0]
def build_url(query): return BASE_URL + '?' + urllib.parse.urlencode(query)

_VIEW_MAP = {
    'List': 50, 'Info list': 52, 'Info list Square': 53, 'Panel': 54, 'Panel Square': 55,
    'Landscape': 56, 'Poster': 57, 'Poster Square': 58, 'Thumbnail': 501, 'Thumbnail Square': 502,
    'Banner': 60, 'Banner Square': 61,
}
_GAME_ACTIONS = {'store_platform', 'play_all', 'play_installed_platform'}

def launcher_choice(slug: str) -> str:
    """
    Returns 'retroarch' or 'standalone' for a RomM platform slug (e.g., 'gba', 'ps2').
    Enum index: 0=RetroArch, 1=Standalone.
    """
    idx = _get_enum(f'{slug}_launcher', 0)
    return 'standalone' if idx == 1 else 'retroarch'

ADDON = xbmcaddon.Addon()
def _is_win():     return sys.platform.startswith('win')
def _is_osx():     return sys.platform.startswith('darwin')
def _is_linux():   return sys.platform.startswith('linux')
def _is_android(): return xbmc.getCondVisibility('System.Platform.Android') == 1

def _get_enum(key: str, default: int = 0) -> int:
    """
    Read <setting type="enum"> as an int index (Omega).
    Falls back to legacy getSetting() if needed.
    """
    try:
        return ADDON.getSettingInt(key)
    except Exception:
        try:
            s = ADDON.getSetting(key)  # legacy API returns string
            return int(s) if (s is not None and s != "") else default
        except Exception:
            return default

def _get_str(key: str, default: str = "") -> str:
    """
    Read string/file/text settings. Works across Kodi versions.
    """
    try:
        return ADDON.getSettingString(key)
    except Exception:
        try:
            s = ADDON.getSetting(key)
            return s if s is not None else default
        except Exception:
            return default

def standalone_exec(slug: str) -> str:
    """
    Pick the per-OS executable (or Android package) from settings.xml.
    """
    if _is_win():
        return _get_str(f'{slug}_standalone_path_win')
    if _is_osx():
        return _get_str(f'{slug}_standalone_path_osx')
    if _is_linux():
        return _get_str(f'{slug}_standalone_path_linux')
    if _is_android():
        # on Android we store a package name in this field (text)
        return _get_str(f'{slug}_standalone_path_android')
    return ""

def launch_with_retroarch(platform_slug: str, rom_path: str):
    """
    Your existing RetroArch path (uses your launcher module).
    """
    xbmc.executebuiltin('Dialog.Close(all,true)')
    xbmc.executebuiltin('Notification(Launching,RetroArch…,1500)')
    from resources.lib.launcher import launch_game_async  # you already use this
    launch_game_async(platform_slug, rom_path)

def launch_with_standalone(exe_or_pkg: str, args_tmpl: str, rom_path: str, platform_slug: str):
    """
    Desktop: runs an EXE/Binary/.app with args (replacing %ROM%).
    Android: starts a package via StartAndroidActivity(package).
    """
    if _is_android():
        pkg = (exe_or_pkg or '').strip()
        if not pkg:
            xbmc.executebuiltin('Notification(Missing package,Set Android package in settings,3500)')
            return
        xbmc.executebuiltin('Dialog.Close(all,true)')
        xbmc.executebuiltin(f'Notification(Launching,{pkg},1500)')
        xbmc.executebuiltin(f'StartAndroidActivity({pkg})')
        return

    exe = (exe_or_pkg or '').strip()
    if not exe:
        xbmc.executebuiltin('Notification(Standalone not set,Check add-on settings,3500)')
        return

    # Quote ROM path and fill %ROM%
    rom_token = f'"{rom_path}"' if _is_win() else shlex.quote(rom_path)
    filled_args = (args_tmpl or '%ROM%').replace('%ROM%', rom_token).strip()

    # Compose command (macOS .app support)
    if _is_osx() and exe.endswith('.app'):
        # Launch a .app bundle with arguments
        cmd = f'open {shlex.quote(exe)} --args {filled_args}'.strip()
    else:
        if _is_win():
            cmd = f'"{exe}" {filled_args}'.strip()
        else:
            cmd = f'{shlex.quote(exe)} {filled_args}'.strip()

    xbmc.executebuiltin('Dialog.Close(all,true)')
    base = os.path.basename(exe)
    xbmc.executebuiltin(f'Notification(Launching,{base or "Standalone"},1500)')
    xbmc.executebuiltin(f'System.Exec({cmd})')

def standalone_args(slug: str) -> str:
    """
    Arguments template; %ROM% will be replaced by the rom path.
    """
    return _get_str(f'{slug}_standalone_args', '%ROM%')

def should_use_retroarch(slug: str) -> bool:
    return launcher_choice(slug) == 'retroarch'

def choose_and_launch(platform_slug: str, rom_path: str):
    mode = launcher_choice(platform_slug)
    if mode == 'retroarch':
        return launch_with_retroarch(platform_slug, rom_path)
    exe  = standalone_exec(platform_slug)
    args = standalone_args(platform_slug)
    return launch_with_standalone(exe, args, rom_path, platform_slug)

def _plat_slug(key: str) -> str:
    return (key or "").strip().lower()
def _choose_launcher_for(platform_key: str) -> str:
    """
    Returns 'retroarch' or 'standalone' based on settings.
    Global setting: default_launcher (0 RA, 1 Standalone)
    Per-platform: launcher_<slug> (0 Default, 1 RA, 2 Standalone)
    """
    a = xbmcaddon.Addon()
    slug = _plat_slug(platform_key)

    # per-platform override (0=Default,1=RA,2=Standalone)
    try:
        per = int(a.getSetting(f'launcher_{slug}') or "0")
    except Exception:
        per = 0

    if per == 1:
        return 'retroarch'
    if per == 2:
        return 'standalone'

    # global default (0=RA,1=Standalone)
    try:
        g = int(a.getSetting('default_launcher') or "0")
    except Exception:
        g = 0
    return 'retroarch' if g == 0 else 'standalone'

def _launch_standalone(platform_key: str, rom_path: str):
    """
    Run a platform-specific external emulator.
    Uses settings: standalone_<slug>_path_win and standalone_<slug>_args
    where %ROM% in args is replaced with the rom file path.
    """
    a = xbmcaddon.Addon()
    slug = _plat_slug(platform_key)
    exe = a.getSetting(f'standalone_{slug}_path_win') or ""
    args = a.getSetting(f'standalone_{slug}_args') or "%ROM%"

    if not exe:
        xbmc.executebuiltin(f'Notification(Missing emulator,Set {slug.upper()} standalone EXE in settings,4000)')
        return

    # Replace token and quote the ROM path
    argline = args.replace('%ROM%', rom_path)
    # Run via System.Exec to avoid blocking UI
    cmd = f'"{exe}" {argline}'
    xbmc.executebuiltin(f'System.Exec({cmd})')


def _canon_single_key(k):
    if k is None:
        return ''
    s = str(k).strip()
    return s.lower()

def _canon_plat_keys(platform_id, platform_slug):
    keys = set()
    a = _canon_single_key(platform_slug)
    b = _canon_single_key(platform_id)
    if a: keys.add(a)
    if b: keys.add(b)
    return keys

def _build_installed_index():
    """
    Platform-scoped indexes so names/ids don't bleed across platforms.
    """
    ids_by_plat = defaultdict(set)
    names_by_plat = defaultdict(set)
    try:
        for it in (installed.list_all() or []):
            pk = _canon_single_key(it.get('platform_key') or it.get('platform') or it.get('pid'))
            if not pk:
                continue
            rid = it.get('rom_id') or it.get('id')
            if rid not in (None, ''):
                try:
                    ids_by_plat[pk].add(int(str(rid)))
                except Exception:
                    pass
            nm = (it.get('name') or os.path.basename(it.get('path') or '')).strip().lower()
            if nm:
                names_by_plat[pk].add(nm)
    except Exception:
        pass
    return ids_by_plat, names_by_plat

def _play_installed(rom_id):
    # find installed entry, then launch
    from resources.lib import installed
    try:
        rid = str(int(rom_id))
    except Exception:
        rid = str(rom_id)

    entry = None
    for it in installed.list_all():
        if isinstance(it, dict) and str(it.get('rom_id')) == rid:
            entry = it
            break
    if not entry:
        xbmc.executebuiltin('Notification(Not installed,Download it first,3000)')
        return

    p = entry.get('path') or ''
    if not p or not xbmcvfs.exists(p):
        xbmc.executebuiltin('Notification(File missing,Re-download to restore,3000)')
        return

    # Launch (you already have play_rom)
    play_rom(entry.get('platform_key') or entry.get('platform') or '', p)

_DETAIL_CALL_BUDGET = 10

def _extract_desc_and_size(rom: dict, client, rom_id):
    # 1) Try to read from list payload
    desc = (
        rom.get('description') or rom.get('summary') or
        rom.get('synopsis') or rom.get('overview') or ''
    ).strip()

    size_bytes = None
    for k in ('file_size', 'size', 'filesize', 'rom_size'):
        v = rom.get(k)
        if v is not None:
            try:
                size_bytes = int(float(v))
                break
            except Exception:
                pass

    if size_bytes is None:
        files = rom.get('files')
        if isinstance(files, list):
            total = 0
            for f in files:
                try:
                    total += int(float((f or {}).get('size') or 0))
                except Exception:
                    pass
            if total > 0:
                size_bytes = total

    # 2) Optional fallback: detail call (budgeted) if still missing
    if (not desc or size_bytes is None) and client and rom_id is not None:
        budget = globals().setdefault('_romm_detail_calls', _DETAIL_CALL_BUDGET)
        if budget > 0:
            try:
                d = client.rom_detail(int(rom_id)) or {}
                globals()['_romm_detail_calls'] = budget - 1

                if not desc:
                    desc = (
                        d.get('description') or d.get('summary') or
                        d.get('synopsis') or d.get('overview') or ''
                    ).strip()

                if size_bytes is None:
                    for k in ('file_size', 'size', 'filesize', 'rom_size'):
                        v = d.get(k)
                        if v:
                            try:
                                size_bytes = int(float(v))
                                break
                            except Exception:
                                pass
                    if size_bytes is None:
                        dfiles = d.get('files')
                        if isinstance(dfiles, list):
                            total = 0
                            for f in dfiles:
                                try:
                                    total += int(float((f or {}).get('size') or 0))
                                except Exception:
                                    pass
                            if total > 0:
                                size_bytes = total
            except Exception:
                pass

    return desc, size_bytes

def show_rom_details(rom_id):
    client = get_client()
    if not client:
        return

    # Try detail first (has richer fields)
    d = {}
    try:
        d = client.rom_detail(int(rom_id)) or {}
    except Exception:
        # Fall back to list search if needed
        pass

    title = d.get('name') or d.get('title') or f"ROM {rom_id}"

    # Description
    desc = (
        d.get('description') or d.get('summary') or
        d.get('synopsis') or d.get('overview') or ''
    ).strip()

    # Size
    size_bytes = None
    for k in ('file_size', 'size', 'filesize', 'rom_size'):
        v = d.get(k)
        if v:
            try:
                size_bytes = int(float(v))
                break
            except Exception:
                pass
    if size_bytes is None:
        files = d.get('files')
        if isinstance(files, list):
            total = 0
            for f in files:
                try:
                    total += int(float((f or {}).get('size') or 0))
                except Exception:
                    pass
            if total > 0:
                size_bytes = total

    # Compose body
    parts = []
    if desc:
        parts.append(desc)
    if size_bytes:
        parts.append(f"\nFile size: {_fmt_bytes(size_bytes)}")
    body = "\n".join(parts) if parts else "No description available."

    xbmcgui.Dialog().textviewer(title, body)

def _refresh_current_container():
    xbmc.executebuiltin('Container.Refresh')
    return True

def _should_apply_context(context_action=None):
    scope = get_setting('program_view_scope','All pages')
    if scope == 'Off': return False
    if scope == 'All pages': return True
    return (context_action in _GAME_ACTIONS)

def _apply_view_now(context_action=None):
    if not _should_apply_context(context_action): return
    chosen = get_setting('program_view','Poster'); vid = _VIEW_MAP.get(chosen, 57)

    # NEW: treat store lists as videos so skins may show overlays
    content = 'files' if context_action == 'store_platform' else 'programs'
    xbmcplugin.setContent(HANDLE, content)

    xbmc.executebuiltin(f'Container.SetViewMode({vid})')


def _nudge_view(context_action=None):
    _apply_view_now(context_action)
    def reapply():
        import time
        chosen = get_setting('program_view','Poster'); vid = _VIEW_MAP.get(chosen, 57)
        for delay in (0.20, 0.50):
            time.sleep(delay)
            path = xbmc.getInfoLabel('Container.FolderPath') or ''
            if not path.startswith('plugin://script.program.romm.launcher/'): 
                return
            if not _should_apply_context(context_action): 
                return
            xbmc.executebuiltin(f'Container.SetViewMode({vid})')
    threading.Thread(target=reapply, daemon=True).start()

def get_client():
    base=get_setting('server_url','').strip(); user=get_setting('username','').strip(); pwd=get_setting('password','').strip()
    verify=get_setting_bool('verify_ssl', True)
    if not base: xbmcgui.Dialog().ok("RomM","Please set Base URL, Username and Password in settings."); return None
    client=RomMClient(base, user, pwd, verify_ssl=verify); client.login(); return client

def _roms_root():
    if is_windows(): d=get_setting('roms_path_win','C:\\\\Games\\\\Roms'); return d or 'C:\\\\Games\\\\Roms'
    return '/storage/emulated/0/Roms'

def root_menu():
    li1=xbmcgui.ListItem(label="RomM Store")
    store_img = find_media_image('store', 'romm_store', 'store_poster')
    if store_img: li1.setArt({'poster': store_img, 'thumb': store_img})
    else: li1.setArt({'icon':'DefaultAddons.png'})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action':'store'}), li1, isFolder=True)

    li2=xbmcgui.ListItem(label="Play Now")
    play_img = find_media_image('play', 'play_now', 'romm_play', 'play_poster')
    if play_img: li2.setArt({'poster': play_img, 'thumb': play_img})
    else: li2.setArt({'icon':'DefaultProgram.png'})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action':'play'}), li2, isFolder=True)

    _nudge_view(context_action=None)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)

def list_platforms(action_key):
    client=get_client(); 
    if not client: return
    plats=client.get_platforms() or []
    for p in plats:
        pid = p.get('id') if isinstance(p, dict) else p
        name = (p.get('name') if isinstance(p, dict) else str(p)) or str(pid)
        slug = (p.get('slug') if isinstance(p, dict) else str(p)) or str(pid)
        li=xbmcgui.ListItem(label=name)
        plat_img = find_media_image(f'platform-{str(slug).lower()}', f'platform-{pid}', f'platform_{str(slug).lower()}', f'platform_{pid}', str(slug).lower())
        if plat_img: li.setArt({'poster': plat_img, 'thumb': plat_img})
        url=build_url({'action':action_key,'pid':str(pid),'pslug':slug,'offset':'0'})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    _nudge_view(context_action=None)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)

def _has_next_from_payload(raw_payload, fetched_count, limit, offset):
    try:
        if isinstance(raw_payload, dict):
            nxt = raw_payload.get('next') or raw_payload.get('next_url') or raw_payload.get('nextPage')
            if isinstance(nxt, str) and nxt.strip():
                return True
            if raw_payload.get('has_next') is True or raw_payload.get('hasNext') is True:
                return True
            total = None
            for k in ('count','total','total_count','totalResults','total_results'):
                v = raw_payload.get(k)
                if isinstance(v, int): total = v; break
            if total is not None:
                return (offset + fetched_count) < total
            for pk in ('pagination','meta','pageInfo','page','pager'):
                v = raw_payload.get(pk)
                if isinstance(v, dict):
                    if v.get('has_next') or v.get('hasNext'): return True
                    t = v.get('total') or v.get('total_count') or v.get('count')
                    if isinstance(t, int): return (offset + fetched_count) < t
        return fetched_count == limit and limit > 0
    except Exception:
        return fetched_count == limit and limit > 0    
    
def _installed_index():
    """Return (ids_set, names_set) of installed ROMs."""
    ids, names = set(), set()
    try:
        for it in (installed.list_all() or []):
            rid = it.get('rom_id')
            if rid is not None:
                try: ids.add(int(rid))
                except: pass
            nm = (it.get('name') or '').strip().lower()
            if nm: names.add(nm)
    except Exception:
        pass
    return ids, names


def list_store_platform(pid, pslug):
    client=get_client(); 
    if not client: return
    page = int((dict(urllib.parse.parse_qsl(sys.argv[2][1:])).get('offset') or '0'))
    page_size = get_setting_int('page_size', 100)
    raw = client._raw_list_roms(platform_id=pid, limit=page_size, offset=page)
    roms=client.list_roms(platform_id=pid, limit=page_size, offset=page) or []
    has_next = _has_next_from_payload(raw, len(roms or []), page_size, page)
    installed_ids, installed_names = _installed_index()
    # build platform-scoped installed sets
    ids_by_plat, names_by_plat = _build_installed_index()
    plat_keys = _canon_plat_keys(platform_id=pid, platform_slug=pslug)
    installed_ids = set()
    installed_names = set()
    for k in plat_keys:
        installed_ids |= ids_by_plat.get(k, set())
        installed_names |= names_by_plat.get(k, set())
    _render_roms_store(
        roms, client,
        platform_id=pid, platform_slug=pslug,
        next_offset=page+page_size, has_next=has_next,
        installed_ids=installed_ids, installed_names=installed_names
    )

def _ensure_platform_folder(platform_key):
    base=_roms_root(); p=path_join(base, str(platform_key))
    if not xbmcvfs.exists(p): xbmcvfs.mkdirs(p)
    return p

def _resolve_rom(client, platform_id, value):
    try:
        q=client.list_roms(platform_id=platform_id, search=str(value), limit=1, offset=0)
        if isinstance(q, list) and q and isinstance(q[0], dict): return q[0]
    except Exception as e:
        pass
    return None

def add_game_row(label, plot="", art=None, rom_id=None, installed=False):

    li = xbmcgui.ListItem(label=("[B]*[/B] " + label) if installed else label)
    li.setProperty('IsPlayable', 'false')
    li.setContentLookup(True)
    if rom_id is not None:
        li.setProperty('romm_id', str(rom_id))

    if art:
        # only keep non-empty values
        li.setArt({k: v for k, v in art.items() if v})

    # Prefer Game Info tag (DialogGameInfo)
    try:
        git = li.getGameInfoTag()
        git.setTitle(label)
        if plot:
            git.setOverview(plot)
    except Exception:
        pass

    # Video plot fallback so skins that only read ListItem.Plot still show text
    vinfo = {'title': label, 'mediatype': 'program'}
    if plot:
        vinfo['plot'] = plot
        vinfo['plotoutline'] = plot
    li.setInfo('files', vinfo)

    return li

def _render_roms_store(roms, client, platform_id, platform_slug, next_offset, has_next, installed_ids=None, installed_names=None):
    handle = HANDLE
    xbmcplugin.setContent(handle, 'files')  # present as Games

    for rom in (roms or []):
        try:
            if not isinstance(rom, dict):
                rom = _resolve_rom(client, platform_id, rom)
                if not isinstance(rom, dict):
                    continue

            name   = rom.get('name') or rom.get('title') or f"ROM {rom.get('id')}"
            rom_id = rom.get('id')

            # Detect if already installed (prefer id, fall back to name match)
            is_installed = False
            try:
                if rom_id is not None and installed_ids is not None:
                    is_installed = int(rom_id) in installed_ids
            except Exception:
                pass
            if not is_installed and installed_names is not None:
                nm = (name or '').strip().lower()
                if nm:
                    is_installed = nm in installed_names

            # Art
            cover_url  = client.build_cover_url(rom, size='big') or ''
            fanart_url = client.build_fanart_url(rom) or ''
            art = {}
            if cover_url:  art.update({'thumb': cover_url, 'poster': cover_url})
            if fanart_url: art.update({'fanart': fanart_url})

            # Description + size → overview (for ALL items)
            desc, size_bytes = _extract_desc_and_size(rom, client, rom_id)
            overview = (desc or "")
            if size_bytes:
                overview += ("\n\n" if overview else "") + f"File size: {_fmt_bytes(size_bytes)}"

            # Build the row via the helper (Game overview + Video plot fallback)
            li = add_game_row(
                label=name,
                plot=overview,
                art=art,
                rom_id=rom_id,
                installed=is_installed
            )
            if is_installed:
                li.setProperty('romm_installed', 'true')  # your skin hook
                li.setProperty('romm_info', '1')  # lets the skin detect RomM items in dialogs

            # Context menu
            cm = []
            if rom_id is not None:
                if is_installed:
                    cm.append(("Play", f'RunPlugin({build_url({"action":"play_installed","id": str(rom_id)})})'))
                else:
                    cm.append(("Download", f'RunPlugin({build_url({"action":"download_rom","id": str(rom_id), "pid": (platform_slug or platform_id)})})'))
                cm.append(("Details", f'RunPlugin({build_url({"action":"show_details","id": str(rom_id)})})'))
            li.addContextMenuItems(cm, replaceItems=True)

            # Click action (your current flow: Download handler; Play lives in context menu)
            if rom_id is not None:
                url = build_url({'action': 'download_rom', 'id': str(rom_id), 'pid': (platform_slug or platform_id)})
                xbmcplugin.addDirectoryItem(handle, url, li, isFolder=False)

        except Exception:
            # swallow and continue to keep the page building robust
            pass

    if has_next:
        li = xbmcgui.ListItem(label="Next Page ▶")
        next_img = find_media_image('next_page', 'next', 'next-page', 'more', 'more_games', 'next_poster')
        if next_img:
            li.setArt({'poster': next_img, 'thumb': next_img})
        url = build_url({'action': 'store_platform', 'pid': platform_id, 'pslug': platform_slug, 'offset': str(next_offset)})
        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)

    _nudge_view(context_action='store_platform')
    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)

def play_root():
    mapping = {}
    try:
        client = get_client()
        if client:
            plats = client.get_platforms() or []
            for pl in plats:
                if isinstance(pl, dict):
                    name = pl.get('name') or pl.get('title') or ''
                    slug = str(pl.get('slug') or '').lower()
                    pid  = str(pl.get('id') or '').strip()
                    if name:
                        if slug: mapping[slug] = name
                        if pid:  mapping[pid]  = name
    except Exception:
        pass

    items = installed.platforms_summary() or []
    total = sum(x.get('count', 0) for x in items)

    # All Installed (pinned first)
    li_all = xbmcgui.ListItem(label=f"All Installed ({total})")
    all_img = find_media_image('all-installed', 'all_installed')
    if all_img: li_all.setArt({'poster': all_img, 'thumb': all_img})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({'action':'play_all'}), li_all, isFolder=True)

    # Platforms A–Z
    def _plat_display_name(p):
        pkey = str(p.get('platform_key') or '')
        return mapping.get(pkey) or mapping.get(pkey.lower()) or p.get('platform_name') or pkey

    for p in sorted(items, key=lambda p: _sortkey_title(_plat_display_name(p))):
        pkey = str(p.get('platform_key'))
        disp_name = _plat_display_name(p)
        label = f"{disp_name} ({p.get('count')})"

        li = xbmcgui.ListItem(label=label)
        plat_img = find_media_image(f'platform-{pkey.lower()}', f'platform-{pkey}', f'platform_{pkey.lower()}', f'platform_{pkey}')
        if plat_img: li.setArt({'poster': plat_img, 'thumb': plat_img})
        xbmcplugin.addDirectoryItem(HANDLE, build_url({'action':'play_installed_platform','pid':pkey}), li, isFolder=True)

    try:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL)
    except Exception:
        pass

    _nudge_view(context_action=None)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=False)


def _sortkey_title(title):
    """
    Case-insensitive A–Z, ignoring leading articles and punctuation.
    """
    t = (title or "").strip()
    k = t.casefold()
    for pref in ("the ", "a ", "an "):
        if k.startswith(pref):
            k = k[len(pref):]
            break
    k = "".join(ch for ch in k if ch.isalnum() or ch.isspace())
    return k


def _render_installed_list(items, context_action):
    handle = HANDLE

    # A–Z by game name (fallback to filename)
    items = sorted(
        items or [],
        key=lambda it: _sortkey_title(it.get('name') or os.path.basename(it.get('path') or ''))
    )

    for it in items:
        name = it.get('name') or os.path.basename(it.get('path') or 'ROM')
        li = xbmcgui.ListItem(label=name)
        art = {}
        if it.get('cover_url'):  art.update({'thumb': it['cover_url'], 'poster': it['cover_url']})
        if it.get('fanart_url'): art.update({'fanart': it['fanart_url']})
        if art: li.setArt(art)

        # keep non-media so default Play/Queue don't appear
        li.setInfo('files', {'title': name})
        li.setProperty('IsPlayable', 'false')
        li.setContentLookup(False)

        # expose rom id for dialogs/context; mark installed for your badge
        rom_id = it.get('rom_id') or it.get('id')
        if rom_id:
            li.setProperty('romm_id', str(rom_id))

        url = build_url({'action': 'play_rom', 'pid': it.get('platform_key'), 'local': it.get('path')})

        # --- HOLD-PRESS CONTEXT MENU (Play + Details + Delete) ---
        cm = []
        if rom_id:
            cm.append(("Play",    f'RunPlugin({build_url({"action":"play_installed","id": str(rom_id)})})'))
            cm.append(("Details", f'RunPlugin({build_url({"action":"show_details","id": str(rom_id)})})'))
        else:
            # Fallbacks if rom_id isn't in installed.json
            cm.append(("Play",    f'RunPlugin({build_url({"action":"play_rom","pid": it.get("platform_key"), "local": it.get("path")})})'))
            # (optional) add a local-details route if you have one:
            # cm.append(("Details", f'RunPlugin({build_url({"action":"show_details_local","path": it.get("path")})})'))

        cm.append(('Delete Game', f'RunPlugin({build_url({"action":"remove_installed","path": it.get("path"), "delete":"1"})})'))
        li.addContextMenuItems(cm, replaceItems=True)
        # --------------------------------------------------------

        xbmcplugin.addDirectoryItem(handle, url, li, isFolder=True)

    # Offer label sorts in the side-blade
    try:
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(handle, xbmcplugin.SORT_METHOD_LABEL)
    except Exception:
        pass

    _nudge_view(context_action=context_action)
    xbmcplugin.endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=False)


def play_all():
    items = installed.list_all()
    _render_installed_list(items, context_action='play_all')

def play_installed_platform(pid):
    items = installed.list_by_platform(pid)
    _render_installed_list(items, context_action='play_installed_platform')

def _derive_filename_from_headers(url, headers, fallback):
    cd = headers.get('Content-Disposition') or headers.get('content-disposition') or ''
    m = re.search(r'filename\*=UTF-8\'\'([^;]+)', cd)
    if m: return urllib.parse.unquote(m.group(1))
    m = re.search(r'filename="([^"]+)"', cd)
    if m: return m.group(1)
    m = re.search(r'filename=([^;]+)', cd)
    if m: return m.group(1).strip()
    tail = url.split('/')[-1]
    if tail and '.' in tail: return urllib.parse.unquote(tail)
    return fallback

def _fmt_bytes(n):
    try:
        n = float(n)
    except Exception:
        return str(n)
    for unit in ('B','KB','MB','GB','TB'):
        if n < 1024.0 or unit == 'TB':
            return f"{n:.1f} {unit}"
        n /= 1024.0

def download_rom(rom_id, platform_key, launch_after=False):
    try:
        rid = str(int(rom_id))
    except Exception:
        rid = str(rom_id)

    items = installed.list_all() or []
    existing = None
    for it in items:
        if not isinstance(it, dict):
            # old/stale entries may be strings; ignore them safely
            continue
        if str(it.get('rom_id')) == rid:
            existing = it
            break

    if existing:
        p = existing.get('path') or ''
        if p and xbmcvfs.exists(p):
            xbmc.executebuiltin(
                f'Notification(Game Already Installed,{os.path.basename(p)},3000)')
            _refresh_current_container()   # <-- ADD THIS LINE
            return
        # stale manifest entry -> prune and proceed with fresh download
        if p:
            try:
                installed.remove_by_path(p)
            except Exception:
                pass
            
            
    client=get_client(); 
    if not client: return
    dest_dir=_ensure_platform_folder(platform_key)
    url1 = client.build_content_url_id_only(int(rom_id))
    fallback_name = f"rom_{rom_id}"
    detail = {}
    try:
        detail = client.rom_detail(int(rom_id)) or {}
    except Exception:
        detail = {}
    display_name = detail.get('name') or detail.get('title') or fallback_name
    cover_url = client.build_cover_url(detail) if detail else ''
    fanart_url = client.build_fanart_url(detail) if detail else ''
    platform_name = (detail.get('platform') or {}).get('name') if isinstance(detail.get('platform'), dict) else str(platform_key)
    try:
        req,_ = client._build_request(url1 if url1.startswith('/') else url1.replace(client.base_url,''), method='GET')
        with client._urlopen(req) as resp:
            headers = dict(resp.headers)
            fname = _derive_filename_from_headers(url1, headers, detail.get('file_name') or detail.get('filename') or fallback_name + '.zip')
            if not os.path.splitext(fname)[1]:
                fname = (detail.get('file_name') or detail.get('filename') or (fallback_name + '.zip'))
            dest_path = path_join(dest_dir, fname)
            # Background progress toast
            dp = xbmcgui.DialogProgressBG()
            dp.create('RomM Launcher', f'Downloading: {display_name}')
            try:
                total = 0
                try:
                    total = int(headers.get('Content-Length') or headers.get('content-length') or 0)
                except Exception:
                    total = 0

                f = xbmcvfs.File(dest_path, 'wb')
                try:
                    # Bigger chunks = fewer Python loops/syscalls. 1MB with total known, else 512KB.
                    chunk_size = 1024 * 1024 if total > 0 else 512 * 1024
                    bytes_read = 0
                    last_percent = -1
                    last_tick = 0.0
                    throttle = 0.20  # seconds between UI updates (5/sec max)

                    while True:
                        chunk = resp.read(chunk_size)
                        if not chunk:
                            break
                        f.write(chunk)
                        bytes_read += len(chunk)

                        now = time.time()
                        if now - last_tick < throttle:
                            continue  # skip UI work if we just updated

                        if total > 0:
                            p = int((bytes_read * 100) / total)
                            if p != last_percent:
                                dp.update(p, f'Downloading: {display_name}',
                                            f'{_fmt_bytes(bytes_read)} / {_fmt_bytes(total)}')
                                last_percent = p
                                last_tick = now
                        else:
                            # no content-length: update roughly every 1MB (and time-throttled)
                            if bytes_read // (1024*1024) != (bytes_read - len(chunk)) // (1024*1024):
                                dp.update(0, f'Downloading: {display_name}', f'{_fmt_bytes(bytes_read)}')
                                last_tick = now
                finally:
                    f.close()
            finally:
                    dp.close()        

            from resources.lib import installed as _installed
            _installed.add_item({
                'rom_id': int(rom_id),
                'platform_key': platform_key,
                'platform_name': platform_name,
                'name': display_name,
                'filename': fname,
                'path': dest_path,
                'cover_url': cover_url,
                'fanart_url': fanart_url,
                'downloaded_at': int(time.time())
            })
            xbmc.executebuiltin(f'Notification(Download complete,{os.path.basename(dest_path)},3000)')
            _refresh_current_container() 
            if launch_after:
                from resources.lib.launcher import launch_game_async
                launch_game_async(platform_key, dest_path)
                xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=False)
            return
    except HTTPError as e:
        try:
            fname2 = detail.get('file_name') or detail.get('filename') or fallback_name + '.zip'
            url2 = client.build_content_url_with_name(int(rom_id), fname2)
            req,_ = client._build_request(url2 if url2.startswith('/') else url2.replace(client.base_url,''), method='GET')
            with client._urlopen(req) as resp:
                headers = dict(resp.headers)
                fname = _derive_filename_from_headers(url2, headers, fname2)
                dest_path = path_join(dest_dir, fname)
                # Background progress toast
                dp = xbmcgui.DialogProgressBG()
                dp.create('RomM Launcher', f'Downloading: {display_name}')
                try:
                    total = 0
                    try:
                        total = int(headers.get('Content-Length') or headers.get('content-length') or 0)
                    except Exception:
                        total = 0

                    f = xbmcvfs.File(dest_path, 'wb')
                    try:
                        # Bigger chunks = fewer Python loops/syscalls. 1MB with total known, else 512KB.
                        chunk_size = 1024 * 1024 if total > 0 else 512 * 1024
                        bytes_read = 0
                        last_percent = -1
                        last_tick = 0.0
                        throttle = 0.20  # seconds between UI updates (5/sec max)

                        while True:
                            chunk = resp.read(chunk_size)
                            if not chunk:
                                break
                            f.write(chunk)
                            bytes_read += len(chunk)

                            now = time.time()
                            if now - last_tick < throttle:
                                continue  # skip UI work if we just updated

                            if total > 0:
                                p = int((bytes_read * 100) / total)
                                if p != last_percent:
                                    dp.update(p, f'Downloading: {display_name}',
                                                f'{_fmt_bytes(bytes_read)} / {_fmt_bytes(total)}')
                                    last_percent = p
                                    last_tick = now
                            else:
                                # no content-length: update roughly every 1MB (and time-throttled)
                                if bytes_read // (1024*1024) != (bytes_read - len(chunk)) // (1024*1024):
                                    dp.update(0, f'Downloading: {display_name}', f'{_fmt_bytes(bytes_read)}')
                                    last_tick = now
                    finally:
                        f.close()
                finally:
                    dp.close()

                from resources.lib import installed as _installed
                _installed.add_item({
                    'rom_id': int(rom_id),
                    'platform_key': platform_key,
                    'platform_name': platform_name,
                    'name': display_name,
                    'filename': fname,
                    'path': dest_path,
                    'cover_url': cover_url,
                    'fanart_url': fanart_url,
                    'downloaded_at': int(time.time())
                })
                xbmc.executebuiltin(f'Notification(Download complete,{os.path.basename(dest_path)},3000)')
                _refresh_current_container() 
                if launch_after:
                    from resources.lib.launcher import launch_game_async
                    launch_game_async(platform_key, dest_path)
                    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=False)
                return
        except Exception as e2:
            xbmc.executebuiltin(f'Notification(Download failed,{str(e2)},5000)')
            return
    except Exception as e:
        xbmc.executebuiltin(f'Notification(Download failed,{str(e)},5000)')
        return

def play_rom(platform_key, local_path):
    # platform_key is your slug/pid (e.g., 'gba', 'ps2', 'dc')
    choose_and_launch(str(platform_key).lower(), local_path)
    

def remove_installed(path, delete_file=False):
    # Always remove from Play Now manifest
    try:
        installed.remove_by_path(path)
    except Exception as e:
        xbmc.executebuiltin(f'Notification(Remove failed,{str(e)},5000)')
        xbmc.executebuiltin('Container.Refresh')
        return

    # Decide whether to delete the file
    do_delete = bool(delete_file)
    if not do_delete:
        # Ask the user if they want to also delete the file (safe default = No)
        try:
            base = os.path.basename(path or '')
            do_delete = xbmcgui.Dialog().yesno(
                'RomM Launcher',
                'Delete the ROM file from disk too?',
                base,
                nolabel='Keep file',
                yeslabel='Delete'
            )
        except Exception:
            do_delete = False

    if do_delete and path:
        try:
            if xbmcvfs.exists(path):
                ok = xbmcvfs.delete(path)
                if ok:
                    xbmc.executebuiltin(f'Notification(File deleted,{os.path.basename(path)},2500)')
                else:
                    xbmc.executebuiltin('Notification(Delete failed,Could not remove file,4000)')
            else:
                xbmc.executebuiltin('Notification(Delete skipped,File not found,3000)')
        except Exception as e:
            xbmc.executebuiltin(f'Notification(Delete failed,{str(e)},5000)')

    xbmc.executebuiltin('Container.Refresh')


def router(paramstring):
    params=dict(urllib.parse.parse_qsl(paramstring)); action=params.get('action')
    if action is None: return root_menu()
    if action=='store': return list_platforms('store_platform')
    if action=='play': return play_root()
    if action=='store_platform': return list_store_platform(params.get('pid'), params.get('pslug'))
    if action=='play_all': return play_all()
    if action=='play_installed_platform': return play_installed_platform(params.get('pid'))
    if action=='download_rom': return download_rom(params.get('id'), params.get('pid'), launch_after=False)
    if action=='dl_then_play': return download_rom(params.get('id'), params.get('pid'), launch_after=True)
    if action=='play_rom': return play_rom(params.get('pid'), params.get('local'))
    if action=='remove_installed':
       delete_flag = str(params.get('delete','')).lower() in ('1','true','yes','y')
       return remove_installed(params.get('path'), delete_file=delete_flag)
    elif action == 'show_details':
        return show_rom_details(params.get('id'))
    elif action == 'play_installed':
        return _play_installed(params.get('id'))
    return root_menu()

if __name__=='__main__':
    ensure_dirs(); router(sys.argv[2][1:] if len(sys.argv)>2 else '')
