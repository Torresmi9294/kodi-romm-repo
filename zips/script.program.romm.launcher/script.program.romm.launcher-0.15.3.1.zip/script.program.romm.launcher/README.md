# RomM Launcher (Omega) — v0.15.3
## What's new
- **Custom art for "Next Page"** rows in ROM lists.
  - Place `resources/media/next_page.png` (or `next.png`, `next-page.png`, `more.png`, `more_games.png`) and it will be used as poster/thumb for the paginator row.

## Existing features
- RomM Store + Play Now, Windows RetroArch launch, media folder for Store/Play/Platforms/All Installed, fast view switching with scope (Off/All pages/Games only).
