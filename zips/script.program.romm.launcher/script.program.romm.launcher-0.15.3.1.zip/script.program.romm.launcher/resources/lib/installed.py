# -*- coding: utf-8 -*-
import os, json, time
from .utils import DATA_PATH, log
MANIFEST = os.path.join(DATA_PATH, 'installed.json')
def _load():
    try:
        with open(MANIFEST, 'r', encoding='utf-8') as f: return json.load(f)
    except Exception: return {'items': []}
def _save(data):
    try:
        with open(MANIFEST, 'w', encoding='utf-8') as f: json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        log(f"[installed] save failed: {e}"); return False
def add_item(item):
    data=_load(); items=data.get('items', [])
    key=(str(item.get('rom_id')), item.get('path'))
    if not any(str(x.get('rom_id'))==key[0] and x.get('path')==key[1] for x in items):
        items.append(item); data['items']=items; _save(data)
def remove_by_path(path):
    data=_load(); items=data.get('items', [])
    items=[x for x in items if x.get('path')!=path]; data['items']=items; _save(data)
def list_all():
    return _load().get('items', [])
def list_by_platform(platform_key):
    return [x for x in list_all() if str(platform_key)==str(x.get('platform_key'))]
def platforms_summary():
    acc={}
    for it in list_all():
        k=str(it.get('platform_key') or 'unknown')
        name=it.get('platform_name') or k
        acc.setdefault(k, {'platform_key':k,'platform_name':name,'count':0})
        acc[k]['count']+=1
    return list(acc.values())
def find_by_rom_id(rom_id):
    rid = str(rom_id)
    for it in list_all():
        if str(it.get('rom_id')) == rid:
            return it
    return None

def remove_by_rom_id(rom_id):
    rid = str(rom_id)
    data = _load()
    items = [x for x in data.get('items', []) if str(x.get('rom_id')) != rid]
    data['items'] = items
    _save(data)
