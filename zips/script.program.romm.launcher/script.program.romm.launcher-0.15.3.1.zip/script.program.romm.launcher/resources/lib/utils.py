# -*- coding: utf-8 -*-
import sys, os, json, hashlib, platform
import xbmc, xbmcaddon, xbmcvfs
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
PROFILE_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
DATA_PATH = os.path.join(PROFILE_PATH)
CACHE_PATH = os.path.join(DATA_PATH, 'cache')
IMG_CACHE = os.path.join(CACHE_PATH, 'images')
JSON_CACHE = os.path.join(CACHE_PATH, 'json')
MEDIA_PATH = os.path.join(ADDON_PATH, 'resources', 'media')
def ensure_dirs():
    for p in (DATA_PATH, CACHE_PATH, IMG_CACHE, JSON_CACHE):
        if not xbmcvfs.exists(p): xbmcvfs.mkdirs(p)
def get_setting(key, default=''):
    try: return ADDON.getSettingString(key)
    except Exception:
        v = ADDON.getSetting(key); return v if v != '' else default
def get_setting_bool(key, default=False):
    try: return ADDON.getSettingBool(key)
    except Exception:
        v = ADDON.getSetting(key); 
        return default if v == '' else str(v).lower()=='true'
def get_setting_int(key, default=0):
    try: return ADDON.getSettingInt(key)
    except Exception:
        v = ADDON.getSetting(key)
        try: return int(v)
        except Exception: return default
def is_android():
    return xbmc.getCondVisibility('System.Platform.Android') or 'android' in platform.system().lower()
def is_windows():
    return xbmc.getCondVisibility('System.Platform.Windows') or platform.system().lower().startswith('win')
def hash_str(s): return hashlib.sha256(s.encode('utf-8')).hexdigest()
def notify(heading, message, time_ms=3000): xbmc.executebuiltin(f'Notification({heading},{message},{time_ms})')
def log(msg, level=xbmc.LOGINFO): xbmc.log(f"[{ADDON_ID}] {msg}", level)
def load_json(s, fallback=None):
    try: return json.loads(s)
    except Exception: return fallback
def path_join(*parts): return os.path.join(*parts)
def win_quote(p): return f'\"{p}\"' if ' ' in p or '(' in p or ')' in p else p
def _exists(path):
    try: return xbmcvfs.exists(path)
    except Exception: 
        try: return os.path.exists(path)
        except Exception: return False
def find_media_image(*bases):
    exts = ('.png', '.jpg', '.jpeg', '.PNG', '.JPG', '.JPEG')
    for base in bases:
        if not base: continue
        for ext in exts:
            p = os.path.join(MEDIA_PATH, base + ext)
            if _exists(p): 
                return p
    return ''
ensure_dirs()
