# -*- coding: utf-8 -*-
import xbmc
xbmc.executebuiltin('ActivateWindow(10001,"plugin://script.program.romm.launcher/",return)')
