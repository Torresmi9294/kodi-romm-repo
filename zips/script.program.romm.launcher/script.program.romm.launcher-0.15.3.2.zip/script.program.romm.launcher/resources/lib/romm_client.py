# -*- coding: utf-8 -*-
import json, urllib.request, urllib.parse, base64, ssl
from urllib.error import HTTPError, URLError
from .utils import log
from .cache import get_json
class RomMClient:
    def __init__(self, base_url, username, password, verify_ssl=True):
        self.base_url = base_url.rstrip('/'); self.username = username; self.password = password
        self.verify_ssl = verify_ssl; self.token=None; self._ctx=None
        if not self.verify_ssl:
            self._ctx = ssl.create_default_context(); self._ctx.check_hostname=False; self._ctx.verify_mode=ssl.CERT_NONE
    def _build_request(self, path, method='GET', data=None, headers=None):
        url = path if str(path).startswith('http') else (self.base_url + str(path))
        hdrs={'Accept':'application/json, */*'}
        if self.token: hdrs['Authorization']=f'Bearer {self.token}'
        elif self.username and self.password:
            b64 = base64.b64encode(f"{self.username}:{self.password}".encode('utf-8')).decode('utf-8')
            hdrs['Authorization']=f'Basic {b64}'
        if headers: hdrs.update(headers)
        data_bytes=None
        if data is not None:
            if isinstance(data,(dict,list)): data_bytes=json.dumps(data).encode('utf-8'); hdrs['Content-Type']='application/json'
            else: data_bytes=data
        return urllib.request.Request(url, data=data_bytes, headers=hdrs, method=method), url
    def _urlopen(self, req):
        return urllib.request.urlopen(req, context=self._ctx) if self._ctx else urllib.request.urlopen(req)
    def login(self):
        try:
            req,_=self._build_request('/api/auth/login',method='POST',data={'username':self.username,'password':self.password},headers={'Accept':'application/json'})
            with self._urlopen(req) as resp:
                js=json.loads(resp.read().decode('utf-8')); token=js.get('token') or js.get('access_token') or js.get('jwt')
                if token: self.token=token; log("RomMClient: JWT login success"); return True
        except HTTPError as e: log(f"RomMClient: login HTTPError {e.code}")
        except URLError as e: log(f"RomMClient: login URLError {e.reason}")
        except Exception as e: log(f"RomMClient: login error {e}")
        return False
    def _cached_get(self, path):
        def fetch():
            req,_=self._build_request(path,method='GET')
            with self._urlopen(req) as resp: return json.loads(resp.read().decode('utf-8'))
        return get_json(self.base_url+path, fetch)
    @staticmethod
    def _unwrap_items(payload):
        if payload is None: return []
        if isinstance(payload, list): return payload
        if isinstance(payload, dict):
            for key in ('results','items','data','roms'):
                if key in payload and isinstance(payload[key], list): return payload[key]
            vals=list(payload.values())
            if vals and all(isinstance(v,(dict,str)) for v in vals): return vals
        return [payload]
    def get_platforms(self):
        try:
            data=self._cached_get('/api/platforms'); items=self._unwrap_items(data); plats=[]
            for it in items:
                if isinstance(it, dict):
                    pid = it.get('id') or it.get('pk') or it.get('uuid') or it.get('slug')
                    name = it.get('name') or it.get('title') or str(pid); slug = it.get('slug') or str(pid)
                else:
                    pid=it; name=str(it); slug=str(it)
                plats.append({'id': pid, 'name': name, 'slug': slug})
            if plats: return plats
        except Exception as e: log(f"get_platforms failed: {e}")
        roms=self.list_roms(limit=500) or []; dedup={}
        for r in roms:
            if not isinstance(r, dict): continue
            pid=r.get('platform_id') or (r.get('platform') or {}).get('id')
            name=(r.get('platform') or {}).get('name') or r.get('platform_name') or 'Unknown'
            slug=(r.get('platform') or {}).get('slug') or r.get('platform_slug') or str(pid or 'unknown')
            if pid or slug: dedup[pid or slug]={'id': pid or slug, 'name': name, 'slug': slug}
        return list(dedup.values())
    def _raw_list_roms(self, platform_id=None, search=None, limit=200, offset=0):
        qs=[]; 
        if platform_id is not None: qs.append(('platform_id', str(platform_id)))
        if search: qs.append(('search', search))
        qs.append(('limit', str(limit))); qs.append(('offset', str(offset)))
        path='/api/roms'; 
        if qs: path += '?' + urllib.parse.urlencode(qs)
        return self._cached_get(path)
    def list_roms(self, platform_id=None, search=None, limit=200, offset=0):
        raw=self._raw_list_roms(platform_id=platform_id, search=search, limit=limit, offset=offset)
        items=self._unwrap_items(raw); result=[]
        for it in items:
            if isinstance(it, dict): result.append(it)
            elif isinstance(it, str): result.append(it)  # resolve in UI
            else: result.append(str(it))
        return result
    def rom_detail(self, rom_id): return self._cached_get(f'/api/roms/{rom_id}')
    def build_cover_url(self, rom, size='big'):
        if isinstance(rom, dict):
            for key in ('cover_big','cover_url','thumb','poster'):
                u = rom.get(key) or (rom.get('assets') or {}).get(key)
                if u: return u if str(u).startswith('http') else (self.base_url + str(u))
            platform_id = rom.get('platform_id') or (rom.get('platform') or {}).get('id') or '0'
            rom_id = rom.get('id'); 
            if rom_id is None: return ''
            return f"{self.base_url}/assets/romm/resources/roms/{platform_id}/{rom_id}/cover/{size}.png"
        return ''

    def build_fanart_url(self, rom, index=0, ext='jpg'):
        if isinstance(rom, dict):
            for key in ('fanart','background','screenshot','fanart_url'):
                u = rom.get(key) or (rom.get('assets') or {}).get(key)
                if u: return u if str(u).startswith('http') else (self.base_url + str(u))
            platform_id = rom.get('platform_id') or (rom.get('platform') or {}).get('id') or '0'
            rom_id = rom.get('id'); 
            return f"{self.base_url}/assets/romm/resources/roms/{platform_id}/{rom_id}/screenshots/{index}.{ext}"
        return ''
    def build_content_url_id_only(self, rom_id):
        return f"{self.base_url}/api/roms/{rom_id}/content"
    def build_content_url_with_name(self, rom_id, filename):
        qfname = urllib.parse.quote(filename)
        return f"{self.base_url}/api/roms/{rom_id}/content/{qfname}"
    