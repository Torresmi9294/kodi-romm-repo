# -*- coding: utf-8 -*-
import os, json, subprocess, xbmc, time, threading, xbmcvfs
from .utils import is_windows, is_android, get_setting, get_setting_bool, log, notify, path_join, win_quote

# ----------------------------
# Core map + candidates
# ----------------------------

def _core_map():
    """
    Accepts either inline JSON or a path to a JSON file.
    Returns {} on any failure.
    """
    raw = (get_setting('core_map_json','') or '').strip()
    if not raw:
        return {}
    # Try as file path first
    looks_like_path = (os.path.sep in raw) or raw.lower().endswith('.json')
    if looks_like_path and os.path.exists(raw):
        try:
            with open(raw, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            log(f"Core map file read error: {e}")
            return {}
    # Try as inline JSON
    try:
        if raw[:1] in ('{','['):
            return json.loads(raw)
        log("Core map provided but not JSON and not a file path; ignoring.")
        return {}
    except Exception as e:
        log(f"Core map JSON parse error: {e}")
        return {}

DEFAULT_CORE_CANDIDATES = {
    'nes': ['nestopia_libretro.dll', 'fceumm_libretro.dll', 'mesen_libretro.dll'],
    'famicom': ['nestopia_libretro.dll', 'fceumm_libretro.dll', 'mesen_libretro.dll'],
    'snes': ['snes9x_libretro.dll', 'bsnes_libretro.dll'],
    'gba': ['mgba_libretro.dll', 'vba_next_libretro.dll'],
    'gb': ['gambatte_libretro.dll'],
    'gbc': ['gambatte_libretro.dll'],
    'genesis': ['genesis_plus_gx_libretro.dll', 'picodrive_libretro.dll', 'blastem_libretro.dll'],
    'megadrive': ['genesis_plus_gx_libretro.dll', 'picodrive_libretro.dll'],
    'sms': ['genesis_plus_gx_libretro.dll', 'picodrive_libretro.dll'],
    'gg': ['genesis_plus_gx_libretro.dll', 'picodrive_libretro.dll'],
    'n64': ['mupen64plus_next_libretro.dll', 'parallel_n64_libretro.dll'],
    'psx': ['swanstation_libretro.dll', 'pcsx_rearmed_libretro.dll'],
    'ps1': ['swanstation_libretro.dll', 'pcsx_rearmed_libretro.dll'],
    'psp': ['ppsspp_libretro.dll'],
    'nintendo_ds': ['melonds_libretro.dll', 'desmume_libretro.dll'],
    'nds': ['melonds_libretro.dll', 'desmume_libretro.dll'],
    '3do': ['opera_libretro.dll'],
    'atari2600': ['stella_libretro.dll'],
    'atari5200': ['atari800_libretro.dll'],
    'atari7800': ['prosystem_libretro.dll'],
    'lynx': ['handy_libretro.dll'],
    'pce': ['beetle_pce_fast_libretro.dll', 'mednafen_pce_fast_libretro.dll'],
    'tg16': ['beetle_pce_fast_libretro.dll', 'mednafen_pce_fast_libretro.dll'],
    'pcengine': ['beetle_pce_fast_libretro.dll', 'mednafen_pce_fast_libretro.dll'],
    'ngp': ['mednafen_ngp_libretro.dll', 'beetle_ngp_libretro.dll'],
    'neogeo': ['fbneo_libretro.dll', 'mame_libretro.dll'],
    'arcade': ['fbneo_libretro.dll', 'mame_libretro.dll'],
    'dreamcast': ['flycast_libretro.dll'],
    'dc': ['flycast_libretro.dll'],
    'saturn': ['yabause_libretro.dll', 'kronos_libretro.dll', 'yabasanshiro_libretro.dll'],
    'ngc': ['dolphin_libretro.dll'],
    'wii': ['dolphin_libretro.dll'],
}

def _find_core_in_dir(cores_dir, candidates, fallback_key=None):
    try:
        entries = [f for f in os.listdir(cores_dir) if f.lower().endswith('.dll')]
    except Exception:
        entries = []
    # Exact match
    for cand in (candidates or []):
        for e in entries:
            if e.lower() == cand.lower():
                return path_join(cores_dir, e)
    # Fuzzy by base name
    for cand in (candidates or []):
        base = cand.lower().replace('_libretro.dll','').replace('.dll','')
        for e in entries:
            if base in e.lower():
                return path_join(cores_dir, e)
    # Fallback on platform key hint
    if fallback_key:
        fk = str(fallback_key).lower()
        for e in entries:
            if fk in e.lower():
                return path_join(cores_dir, e)
    return None

def _resolve_core_windows(platform_key, rom_path):
    cores = _core_map()
    core_rel = cores.get(str(platform_key)) or cores.get(str(platform_key).lower())
    retroarch = get_setting('retroarch_path_win','')
    if not retroarch or not os.path.exists(retroarch):
        notify("RetroArch not found","Set 'RetroArch path (Windows)' in settings."); return None
    ra_dir = os.path.dirname(retroarch)

    if core_rel:
        core_path = core_rel if os.path.isabs(core_rel) else path_join(ra_dir, core_rel)
        if os.path.exists(core_path):
            return core_path

    cores_dir = get_setting('cores_folder_win','').strip() or path_join(ra_dir, 'cores')
    candidates = DEFAULT_CORE_CANDIDATES.get(str(platform_key).lower(), [])
    core_path = _find_core_in_dir(cores_dir, candidates, fallback_key=platform_key)
    if core_path and os.path.exists(core_path):
        return core_path

    if core_rel:
        alt = core_rel if os.path.isabs(core_rel) else path_join(cores_dir, os.path.basename(core_rel))
        if os.path.exists(alt):
            return alt
    return None

# ----------------------------
# Windows UX helpers
# ----------------------------

def _wait_for_window(title, timeout_ms=6000):
    try:
        import ctypes
        user32 = ctypes.windll.user32
        t0 = time.time()
        while (time.time() - t0) * 1000 < timeout_ms:
            hwnd = user32.FindWindowW(None, title)
            if hwnd:
                return hwnd
            time.sleep(0.05)
    except Exception:
        pass
    return None

def _win_minimize_kodi():
    try:
        xbmc.executebuiltin('Minimize')
    except Exception:
        try: xbmc.executebuiltin('Action(minimize)')
        except Exception: pass
    try:
        import ctypes
        user32 = ctypes.windll.user32
        hwnd = user32.FindWindowW(None, "Kodi")
        if hwnd:
            user32.ShowWindow(hwnd, 6)  # SW_MINIMIZE
    except Exception:
        pass

def _win_restore_kodi():
    try:
        xbmc.executebuiltin('Restore')
    except Exception:
        try: xbmc.executebuiltin('Action(Fullscreen)')
        except Exception: pass
    try:
        import ctypes
        user32 = ctypes.windll.user32
        hwnd = user32.FindWindowW(None, "Kodi")
        if hwnd:
            user32.ShowWindow(hwnd, 9)  # SW_RESTORE
            user32.SetForegroundWindow(hwnd)
    except Exception:
        pass

# ----------------------------
# Windows launch
# ----------------------------

def _launch_windows_blocking(platform_key, rom_path):
    retroarch = get_setting('retroarch_path_win','')
    core_path = _resolve_core_windows(platform_key, rom_path)
    if not core_path:
        notify("Missing core", f"No core found for '{platform_key}'. Set 'RetroArch cores folder (Windows)' or fill Core map JSON.")
        return False
    cmd = [retroarch, '-L', core_path, '-f', rom_path]
    log("Launching: " + " ".join(cmd))
    try:
        proc = subprocess.Popen(cmd)
        hwnd = _wait_for_window("RetroArch", timeout_ms=6000)
        if hwnd: _win_minimize_kodi()
        proc.wait()
        _win_restore_kodi()
        return True
    except Exception as e:
        notify("Launch failed", str(e))
        try: _win_restore_kodi()
        except Exception: pass
        return False

# ----------------------------
# Android launch
# ----------------------------

def _start_android_activity(package, activity="", action="android.intent.action.VIEW",
                            mimetype="", uri=""):
    """
    Wrapper for Kodi's StartAndroidActivity builtin.
    """
    esc = lambda s: (s or "").replace('"', '\\"')
    cmd = f'StartAndroidActivity("{esc(package)}","{esc(activity)}","{esc(action)}","{esc(mimetype)}","{esc(uri)}")'
    log(f"Android: {cmd}")
    xbmc.executebuiltin(cmd)

def _android_pkg_and_activity_from_setting(platform_key):
    """
    Reads '{platform}_standalone_path_android' which stores either:
      - 'com.pkg'
      - 'com.pkg/.Activity'
    Returns (package, activity)
    """
    raw = (get_setting(f"{platform_key}_standalone_path_android", "") or "").strip()
    if not raw:
        return ("", "")
    if "/" in raw:
        pkg, act = raw.split("/", 1)
        return (pkg.strip(), act.strip())
    return (raw, "")

def _make_file_uri(rom_path):
    rp = (rom_path or "").replace("\\", "/")
    return rp if rp.startswith("file://") else "file://" + rp

def _ensure_android_public_copy(rom_path):
    """
    On Android 11+, external emulators usually cannot read Kodi's private storage.
    Copy ROM to a public folder so ACTION_VIEW works:
      /storage/emulated/0/Download/RomMLauncher
    Returns a filesystem path (not a URI). Falls back to original on failure.
    """
    try:
        rp = (rom_path or "").replace("\\", "/")
        # Already public? keep as-is
        if rp.startswith("/storage/emulated/0") or rp.startswith("/sdcard"):
            return rp

        dst_dir = "/storage/emulated/0/Download/RomMLauncher"
        try:
            if not xbmcvfs.exists(dst_dir):
                # best-effort: create parent(s)
                xbmcvfs.mkdir("/storage/emulated/0/Download")
                xbmcvfs.mkdir(dst_dir)
        except Exception:
            pass

        fname = os.path.basename(rp)
        dst_path = dst_dir.rstrip("/") + "/" + fname

        # remove any previous copy
        try:
            if xbmcvfs.exists(dst_path):
                xbmcvfs.delete(dst_path)
        except Exception:
            pass

        ok = xbmcvfs.copy(rp, dst_path)
        if ok and xbmcvfs.exists(dst_path):
            log(f"Android: copied ROM to public path: {dst_path}")
            return dst_path
        else:
            log("Android: public copy failed; using original path")
            return rp
    except Exception as e:
        log(f"_ensure_android_public_copy error: {e}")
        return rom_path


def _launch_android_blocking(platform_key, rom_path):
    """
    Android:
      - If {platform}_launcher == Standalone → launch package/activity with VIEW + file:// ROM
      - Else RetroArch package (configurable) with VIEW + file:// ROM
    """
    try:
        launcher_mode = int(get_setting(f"{platform_key}_launcher", 0) or 0)  # 0=RetroArch, 1=Standalone
    except Exception:
        launcher_mode = 0

    # Ensure external emulator can read the file
    rom_public = _ensure_android_public_copy(rom_path)
    file_uri = _make_file_uri(rom_public)


    if launcher_mode == 1:
        pkg, act = _android_pkg_and_activity_from_setting(platform_key)
        if not pkg:
            notify("Android", f"No Android package set for {platform_key}. Open Settings → Emulators and fill the package.")
            return False
        try:
            _start_android_activity(pkg, act, "android.intent.action.VIEW", "", file_uri)
            return True
        except Exception as e:
            log(f"Android standalone launch error: {e}")
            notify("Launch failed", "Couldn’t start the Android emulator.")
            return False

    # RetroArch path
    ra_pkg = (get_setting("retroarch_pkg_android", "org.retroarch") or "org.retroarch").strip()
    ra_act = (get_setting("retroarch_activity_android", "") or "").strip()  # optional
    try:
        _start_android_activity(ra_pkg, ra_act, "android.intent.action.VIEW", "", file_uri)
        return True
    except Exception as e:
        log(f"Android RetroArch launch error: {e}")
        notify("Launch failed", "Couldn’t start RetroArch on Android.")
        return False

# ----------------------------
# Public API
# ----------------------------

def launch_game_async(platform_slug_or_id, rom_path):
    """
    Non-blocking launcher for Kodi UI. Spawns a daemon thread and returns immediately.
    """
    target = None
    if is_windows():
        target = _launch_windows_blocking
    elif is_android():
        target = _launch_android_blocking
    else:
        notify("RomM Launcher", "Unsupported platform (yet).")
        return False

    try:
        th = threading.Thread(target=target, args=(platform_slug_or_id, rom_path), daemon=True)
        th.start()
        return True
    except Exception as e:
        log(f"launch_game_async spawn error: {e}")
        notify("Launch failed", "Could not start launcher thread.")
        return False

def launch_game(platform_slug_or_id, rom_path):
    """
    Blocking launcher (used when you explicitly want to wait).
    """
    if is_windows():
        return _launch_windows_blocking(platform_slug_or_id, rom_path)
    elif is_android():
        return _launch_android_blocking(platform_slug_or_id, rom_path)
    else:
        notify("RomM Launcher","Unsupported platform (yet).")
        return False
