import sys
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from resources.lib import ra_client

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]

def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)

def list_root():
    li1 = xbmcgui.ListItem(label="Profile")
    xbmcplugin.addDirectoryItem(HANDLE, build_url({"action": "profile"}), li1, isFolder=True)

    li2 = xbmcgui.ListItem(label="People You Follow")
    xbmcplugin.addDirectoryItem(HANDLE, build_url({"action": "friends"}), li2, isFolder=True)

    xbmcplugin.endOfDirectory(HANDLE)

def show_profile():
    user = ADDON.getSetting("ra_username")
    if not user:
        xbmcgui.Dialog().ok("RetroAchievements", "Please set your RA username & API key in settings.")
        return
    profile = ra_client.get_user_profile(user)
    li = xbmcgui.ListItem(label=f"{profile.get('User', user)} — {profile.get('Points', 0)} pts")
    pic = profile.get("UserPic", "")
    if isinstance(pic, dict):
        pic = pic.get("Icon", "") or pic.get("Url", "")
    li.setArt({"icon": pic, "thumb": pic})
    li.setInfo("video", {"title": f"Rank: {profile.get('Rank', 'N/A')}", "plot": profile.get("Motto", "")})
    xbmcplugin.addDirectoryItem(HANDLE, build_url({"action": "recent", "user": user}), xbmcgui.ListItem(label="Recent Unlocks"), isFolder=True)
    xbmcplugin.addDirectoryItem(HANDLE, "", li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def show_recent(user: str):
    data = ra_client.get_user_recent_unlocks(user)
    for item in data or []:
        title = item.get("GameTitle") or item.get("AchievementTitle") or "Achievement"
        li = xbmcgui.ListItem(label=title)
        li.setInfo("video", {"plot": item.get("Description", "")})
        badge = item.get("BadgeURL", "") or item.get("BadgeUrl", "")
        li.setArt({"thumb": badge, "icon": badge})
        xbmcplugin.addDirectoryItem(HANDLE, "", li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE)

def show_friends():
    user = ADDON.getSetting("ra_username")
    if not user:
        xbmcgui.Dialog().ok("RetroAchievements", "Please set your RA username & API key in settings.")
        return
    friends = ra_client.get_user_friends(user)
    for f in friends or []:
        uname = f.get("User") or f.get("Username")
        if not uname:
            continue
        label = f"{uname} — {f.get('Points', 0)} pts"
        li = xbmcgui.ListItem(label=label)
        pic = f.get("UserPic", "")
        if isinstance(pic, dict):
            pic = pic.get("Icon", "") or pic.get("Url", "")
        li.setArt({"thumb": pic})
        url = build_url({"action": "recent", "user": uname})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")
    if not action:
        return list_root()
    if action == "profile":
        return show_profile()
    if action == "friends":
        return show_friends()
    if action == "recent":
        return show_recent(params.get("user") or ADDON.getSetting("ra_username"))

if __name__ == '__main__':
    router(sys.argv[2][1:])
