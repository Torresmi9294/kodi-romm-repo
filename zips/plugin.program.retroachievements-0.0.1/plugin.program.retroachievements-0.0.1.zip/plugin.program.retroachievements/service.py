import xbmc
import xbmcgui
import xbmcaddon
from resources.lib import ra_client

ADDON = xbmcaddon.Addon()
INTERVAL = 300

class Monitor(xbmc.Monitor):
    pass

if __name__ == '__main__':
    mon = Monitor()
    if ADDON.getSettingBool('notify_unlocks'):
        user = ADDON.getSetting('ra_username')
        if user:
            try:
                recents = (ra_client.get_user_recent_unlocks(user, count=5) or [])[:5]
                if recents:
                    xbmcgui.Dialog().notification('RetroAchievements', f"Recent unlocks fetched for {user}", xbmcgui.NOTIFICATION_INFO, 5000)
            except Exception:
                pass
    while not mon.abortRequested():
        if mon.waitForAbort(INTERVAL):
            break
