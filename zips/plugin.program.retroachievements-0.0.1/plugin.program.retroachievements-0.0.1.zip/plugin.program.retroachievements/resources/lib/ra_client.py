import json
import urllib.parse
import xbmcaddon
from . import cache

try:
    import requests
    _HAS_REQUESTS = True
except Exception:
    import urllib.request
    _HAS_REQUESTS = False

ADDON = xbmcaddon.Addon()
BASE = "https://retroachievements.org"
API = f"{BASE}/API/"

def _creds():
    return {
        "z": ADDON.getSetting("ra_username"),
        "y": ADDON.getSetting("ra_api_key"),
    }

def _fetch(url, params):
    if _HAS_REQUESTS:
        r = requests.get(url, params=params, timeout=15)
        r.raise_for_status()
        ct = r.headers.get("Content-Type", "")
        return r.json() if "application/json" in ct else json.loads(r.text)
    else:
        full = url + "?" + urllib.parse.urlencode(params)
        with urllib.request.urlopen(full, timeout=20) as resp:
            data = resp.read().decode("utf-8")
        try:
            return json.loads(data)
        except Exception:
            return {}

def _get(path: str, params: dict, cache_key: str = None, ttl_sec: int = 300):
    params = {**_creds(), **(params or {})}
    key = cache_key or (path + "?" + urllib.parse.urlencode(params))
    if ttl_sec:
        c = cache.get(key, ttl_sec)
        if c is not None:
            return c
    url = urllib.parse.urljoin(API, path)
    data = _fetch(url, params)
    if ttl_sec:
        cache.set(key, data)
    return data

def get_user_summary(username: str, ttl_sec=300):
    return _get("API_GetUserSummary.php", {"u": username}, f"summary:{username}", ttl_sec)

def get_user_recent_unlocks(username: str, count=20, ttl_sec=120):
    return _get("API_GetUserRecentAchievements.php", {"u": username, "c": count}, f"recent:{username}:{count}", ttl_sec)

def get_user_friends(username: str, ttl_sec=600):
    return _get("API_GetFriends.php", {"u": username}, f"friends:{username}", ttl_sec)

def get_user_profile(username: str, ttl_sec=600):
    return _get("API_GetUserProfile.php", {"u": username}, f"profile:{username}", ttl_sec)
