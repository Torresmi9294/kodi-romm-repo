import json
import time
from xbmcvfs import exists, mkdirs, File

CACHE_DIR = "special://profile/addon_data/plugin.program.retroachievements/cache"

def _ensure_dir(path):
    if not exists(path):
        mkdirs(path)

def _path(key: str) -> str:
    safe = key.replace("/", "_")
    return f"{CACHE_DIR}/{safe}.json"

def get(key: str, max_age_seconds: int):
    _ensure_dir(CACHE_DIR)
    p = _path(key)
    if not exists(p):
        return None
    f = File(p)
    try:
        data = json.loads(f.readBytes().decode("utf-8"))
    finally:
        f.close()
    if time.time() - data.get("_ts", 0) > max_age_seconds:
        return None
    return data.get("payload")

def set(key: str, payload):
    _ensure_dir(CACHE_DIR)
    p = _path(key)
    f = File(p, 'w')
    try:
        blob = json.dumps({"_ts": time.time(), "payload": payload}, ensure_ascii=False)
        f.write(bytearray(blob, 'utf-8'))
    finally:
        f.close()
