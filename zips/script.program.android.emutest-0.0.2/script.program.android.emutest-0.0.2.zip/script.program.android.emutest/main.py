# -*- coding: utf-8 -*-
import sys
import xbmc
import xbmcgui
import xbmcaddon

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')

# Default known emulators. Users can also set a custom package/activity in settings.
KNOWN = [
    {"label": "RetroArch", "pkg": "com.retroarch", "act": "com.retroarch.browser.retroactivity.RetroActivityFuture"},
    {"label": "Eden (Switch)", "pkg": "dev.eden.eden_emulator", "act": ""},
    {"label": "NetherSX2 (PS2)", "pkg": "xyz.aethersx2.android", "act": ""},
    {"label": "PPSSPP", "pkg": "org.ppsspp.ppsspp", "act": "org.ppsspp.ppsspp.PpssppActivity"},
    {"label": "Dolphin (official)", "pkg": "org.dolphinemu.dolphinemu", "act": "org.dolphinemu.dolphinemu.ui.main.MainActivity"},
    {"label": "M64Plus FZ", "pkg": "org.mupen64plusae.v3.fzurita", "act": "paulscode.android.mupen64plusae.SplashActivity"},
    {"label": "Yaba Sanshiro 2", "pkg": "org.uoyabause.uranus", "act": "org.uoyabause.uranus.SplashActivity"},
    {"label": "Custom...", "pkg": "", "act": ""}
]

def select_emulator():
    labels = [k["label"] for k in KNOWN]
    idx = xbmcgui.Dialog().select("Choose emulator", labels)
    if idx < 0:
        return None
    choice = KNOWN[idx]
    if choice["label"] == "Custom...":
        pkg = ADDON.getSettingString("custom_package") or ""
        act = ADDON.getSettingString("custom_activity") or ""
        if not pkg:
            pkg = xbmcgui.Dialog().input("Android package (e.g., com.retroarch)")
        if act is None:
            act = ""
        return {"label": "Custom", "pkg": pkg, "act": act}
    return choice

def browse_rom():
    # Let user pick any file path Kodi can see
    return xbmcgui.Dialog().browse(1, "Pick a ROM", "files", "")

def build_start_builtin(pkg, act, mime, uri):
    # Kodi builtin: StartAndroidActivity(package[, activity][, intent][, mimeType][, dataURI])
    intent = ADDON.getSettingString("intent_action") or ""
    parts = ['StartAndroidActivity("%s"' % pkg]
    if act:
        parts.append(',"%s"' % act)
    else:
        parts.append(',')
    if intent:
        parts.append(',"%s"' % intent)
    else:
        parts.append(',')
    if mime:
        parts.append(',"%s"' % mime)
    else:
        parts.append(',')
    if uri:
        parts.append(',"%s"' % uri)
    parts.append(')')
    return "".join(parts)

def main():
    if xbmc.getCondVisibility('System.Platform.Android') != 1:
        xbmcgui.Dialog().ok("Android only", "This test add-on only runs on Android builds of Kodi.")
        return

    choice = select_emulator()
    if not choice:
        return

    rom_path = browse_rom()
    if not rom_path:
        return

    # Default MIME and URI format
    mime = ADDON.getSettingString("mime_type") or "application/octet-stream"

    uri = rom_path
    if not rom_path.startswith(("file://", "content://")):
        if rom_path.startswith(("/", "sdcard", "storage", "mnt")):
            uri = "file://" + rom_path

    builtin = build_start_builtin(choice["pkg"], choice["act"], mime, uri)
    xbmc.log("[%s] Launching: %s" % (ADDON_ID, builtin), xbmc.LOG_INFO)

    ok = xbmcgui.Dialog().yesno("Launch emulator?",
                                "Emulator: %s\nPackage: %s\nActivity: %s\nMIME: %s\nURI: %s" %
                                (choice["label"], choice["pkg"], choice["act"] or "(default)", mime, uri),
                                yeslabel="Launch", nolabel="Cancel")
    if not ok:
        return

    xbmc.executebuiltin(builtin)

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        xbmcgui.Dialog().notification("Emu Test", "Error: %s" % e, xbmcgui.NOTIFICATION_ERROR)
